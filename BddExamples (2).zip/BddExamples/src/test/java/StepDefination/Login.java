package StepDefination;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Login {
	
	WebDriver driver;
	@Given("^User is on Home Page$")
	public void user_is_on_Home_Page() throws Throwable {
	    Thread.sleep(3000);
	    System.setProperty("webdriver.chrome.driver", "C:/Users/sakraut/Desktop/libs/chromedriver.exe");
		 driver=new ChromeDriver();
	     driver.navigate().to("http://demowebshop.tricentis.com");
	}

	@When("^User Navigate to LogIn Page$")
	public void user_Navigate_to_LogIn_Page() throws Throwable {
		Thread.sleep(3000);
		driver.findElement(By.className("ico-login")).click();
	}

	@When("^User enters valid Email$")
	public void user_enters_valid_Email() throws Throwable {
		Thread.sleep(3000);
		   driver.findElement(By.name("Email")).sendKeys("sakshi123@gmail.com");
	}

	@When("^User enters valid Password$")
	public void user_enters_valid_Password() throws Throwable {
		Thread.sleep(3000);
		 driver.findElement(By.name("Password")).sendKeys("sakshi");
	}

	@Then("^Message displayed Successfull login$")
	public void message_displayed_Successfull_login() throws Throwable {
		 driver.findElement(By.xpath("//input[@value='Log in']")).click();
		 Thread.sleep(3000);
		 driver.close();
	}


}
