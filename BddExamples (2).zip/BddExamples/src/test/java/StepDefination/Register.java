package StepDefination;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
public class Register {

	WebDriver driver;
	@Given("^User is in home page of demoshop$")
	public void user_is_in_home_page_of_demoshop() {
	   
		System.setProperty("webdriver.chrome.driver", "C:/Users/sakraut/Desktop/libs/chromedriver.exe");
		 driver=new ChromeDriver();
	     driver.navigate().to("http://demowebshop.tricentis.com");
	}
	

  @And("^register linktest displayed$")
   public void register_linktest_displayed()   {
    // Write code here that turns the phrase above into concrete actions
  
    }



	@When("^User navigate to register$")
	public void user_navigate_to_register() {
	    // Write code here that turns the phrase above into concrete actions
		driver.findElement(By.className("ico-register")).click();
	}

	@When("^User enter appropiate gender$")
	public void user_enter_appropiate_gender() {
	    // Write code here that turns the phrase above into concrete actions
		driver.findElement(By.id("gender-female")).click();
	}

	@When("^User enters valid FirstName and LastName$")
	public void user_enters_valid_FirstName_and_LastName()  {
	    // Write code here that turns the phrase above into concrete actions
		driver.findElement(By.name("FirstName")).sendKeys("sakshi");
	     driver.findElement(By.name("LastName")).sendKeys("raut");
	}

	@When("^User enters valid  Email$")
	public void user_enters_valid_Email() {
	    // Write code here that turns the phrase above into concrete actions
		   driver.findElement(By.name("Email")).sendKeys("sakshi123@gmail.com");
	}

	@When("^User enters valid  Password$")
	public void user_enters_valid_Password() {
	    // Write code here that turns the phrase above into concrete actions
		 driver.findElement(By.name("Password")).sendKeys("sakshi");
	}

	@When("^User enters valid  Confirm Password$")
	public void user_enters_valid_Confirm_Password()   {
	    // Write code here that turns the phrase above into concrete actions
		 driver.findElement(By.name("ConfirmPassword")).sendKeys("sakshi");
	}

	@Then("^User is Register successfully$")
	public void user_is_Register_successfully()   {
	    // Write code here that turns the phrase above into concrete actions
		 driver.findElement(By.name("register-button")).click();
	   //  driver.findElement(By.xpath("button-1 register-continue-button")).click();
	}

	@Then("^log out link displayed$")
	public void log_out_link_displayed() throws InterruptedException   {
	    // Write code here that turns the phrase above into concrete actions
		 driver.findElement(By.name("ico-logout")).click();
		 Thread.sleep(3000);
		 driver.close();
	}


}
